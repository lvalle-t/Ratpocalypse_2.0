<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="wall-2" tilewidth="32" tileheight="32" tilecount="128" columns="16">
 <image source="../Tilesets/wall-2-no water- 3 tiles tall.png" width="512" height="256"/>
 <wangsets>
  <wangset name="wall-2" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="3" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="16" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="17" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="18" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="19" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="20" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="32" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="33" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="34" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="35" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="36" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="48" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="49" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="50" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="51" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="52" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="65" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="66" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="67" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
