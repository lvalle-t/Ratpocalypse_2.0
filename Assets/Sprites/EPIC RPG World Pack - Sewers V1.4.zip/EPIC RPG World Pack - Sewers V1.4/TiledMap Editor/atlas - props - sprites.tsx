<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="atlas - props - sprites" tilewidth="160" tileheight="160" tilecount="796" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1591">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_0.png"/>
 </tile>
 <tile id="1592">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_1.png"/>
 </tile>
 <tile id="1593">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_2.png"/>
 </tile>
 <tile id="1594">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_3.png"/>
 </tile>
 <tile id="1595">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_4.png"/>
 </tile>
 <tile id="1596">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_5.png"/>
 </tile>
 <tile id="1597">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_6.png"/>
 </tile>
 <tile id="1598">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_7.png"/>
 </tile>
 <tile id="1599">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_8.png"/>
 </tile>
 <tile id="1600">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_9.png"/>
 </tile>
 <tile id="1601">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_10.png"/>
 </tile>
 <tile id="1602">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_11.png"/>
 </tile>
 <tile id="1603">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_12.png"/>
 </tile>
 <tile id="1604">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_13.png"/>
 </tile>
 <tile id="1605">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones - color scheme 2_14.png"/>
 </tile>
 <tile id="1606">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_15.png"/>
 </tile>
 <tile id="1607">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_16.png"/>
 </tile>
 <tile id="1608">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_17.png"/>
 </tile>
 <tile id="1609">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_18.png"/>
 </tile>
 <tile id="1610">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_19.png"/>
 </tile>
 <tile id="1611">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_20.png"/>
 </tile>
 <tile id="1612">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_21.png"/>
 </tile>
 <tile id="1613">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_22.png"/>
 </tile>
 <tile id="1614">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_24.png"/>
 </tile>
 <tile id="1615">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_25.png"/>
 </tile>
 <tile id="1616">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_26.png"/>
 </tile>
 <tile id="1617">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_28.png"/>
 </tile>
 <tile id="1618">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_29.png"/>
 </tile>
 <tile id="1619">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_30.png"/>
 </tile>
 <tile id="1620">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_31.png"/>
 </tile>
 <tile id="1621">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_33.png"/>
 </tile>
 <tile id="1622">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_34.png"/>
 </tile>
 <tile id="1623">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 2_35.png"/>
 </tile>
 <tile id="1624">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 23_23.png"/>
 </tile>
 <tile id="1625">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 27_27.png"/>
 </tile>
 <tile id="1626">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones - color scheme 32_32.png"/>
 </tile>
 <tile id="1627">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones 31_.png"/>
 </tile>
 <tile id="1628">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_0.png"/>
  <animation>
   <frame tileid="1628" duration="100"/>
   <frame tileid="1629" duration="100"/>
   <frame tileid="1630" duration="100"/>
   <frame tileid="1631" duration="100"/>
   <frame tileid="1632" duration="100"/>
   <frame tileid="1633" duration="100"/>
   <frame tileid="1634" duration="100"/>
   <frame tileid="1635" duration="100"/>
  </animation>
 </tile>
 <tile id="1629">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_1.png"/>
 </tile>
 <tile id="1630">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_2.png"/>
 </tile>
 <tile id="1631">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_3.png"/>
 </tile>
 <tile id="1632">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_4.png"/>
 </tile>
 <tile id="1633">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_5.png"/>
 </tile>
 <tile id="1634">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_6.png"/>
 </tile>
 <tile id="1635">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - frame_7.png"/>
 </tile>
 <tile id="1636">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1636" duration="100"/>
   <frame tileid="1637" duration="100"/>
   <frame tileid="1638" duration="100"/>
   <frame tileid="1639" duration="100"/>
   <frame tileid="1640" duration="100"/>
   <frame tileid="1641" duration="100"/>
   <frame tileid="1642" duration="100"/>
   <frame tileid="1643" duration="100"/>
  </animation>
 </tile>
 <tile id="1637">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_1.png"/>
 </tile>
 <tile id="1638">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_2.png"/>
 </tile>
 <tile id="1639">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_3.png"/>
 </tile>
 <tile id="1640">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_4.png"/>
 </tile>
 <tile id="1641">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_5.png"/>
 </tile>
 <tile id="1642">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_6.png"/>
 </tile>
 <tile id="1643">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0 - transparency - frame_7.png"/>
 </tile>
 <tile id="1644">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_0.png"/>
 </tile>
 <tile id="1645">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_0_.png"/>
 </tile>
 <tile id="1646">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_0.png"/>
  <animation>
   <frame tileid="1646" duration="100"/>
   <frame tileid="1647" duration="100"/>
   <frame tileid="1648" duration="100"/>
   <frame tileid="1649" duration="100"/>
   <frame tileid="1650" duration="100"/>
   <frame tileid="1651" duration="100"/>
   <frame tileid="1652" duration="100"/>
   <frame tileid="1653" duration="100"/>
  </animation>
 </tile>
 <tile id="1647">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_1.png"/>
 </tile>
 <tile id="1648">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_2.png"/>
 </tile>
 <tile id="1649">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_3.png"/>
 </tile>
 <tile id="1650">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_4.png"/>
 </tile>
 <tile id="1651">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_5.png"/>
 </tile>
 <tile id="1652">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_6.png"/>
 </tile>
 <tile id="1653">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - frame_7.png"/>
 </tile>
 <tile id="1654">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1654" duration="100"/>
   <frame tileid="1655" duration="100"/>
   <frame tileid="1656" duration="100"/>
   <frame tileid="1657" duration="100"/>
   <frame tileid="1658" duration="100"/>
   <frame tileid="1659" duration="100"/>
   <frame tileid="1660" duration="100"/>
   <frame tileid="1661" duration="100"/>
  </animation>
 </tile>
 <tile id="1655">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_1.png"/>
 </tile>
 <tile id="1656">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_2.png"/>
 </tile>
 <tile id="1657">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_3.png"/>
 </tile>
 <tile id="1658">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_4.png"/>
 </tile>
 <tile id="1659">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_5.png"/>
 </tile>
 <tile id="1660">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_6.png"/>
 </tile>
 <tile id="1661">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1 - transparency - frame_7.png"/>
 </tile>
 <tile id="1662">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_1.png"/>
 </tile>
 <tile id="1663">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_0.png"/>
  <animation>
   <frame tileid="1663" duration="100"/>
   <frame tileid="1664" duration="100"/>
   <frame tileid="1665" duration="100"/>
   <frame tileid="1666" duration="100"/>
   <frame tileid="1667" duration="100"/>
   <frame tileid="1668" duration="100"/>
   <frame tileid="1669" duration="100"/>
   <frame tileid="1670" duration="100"/>
  </animation>
 </tile>
 <tile id="1664">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_1.png"/>
 </tile>
 <tile id="1665">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_2.png"/>
 </tile>
 <tile id="1666">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_3.png"/>
 </tile>
 <tile id="1667">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_4.png"/>
 </tile>
 <tile id="1668">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_5.png"/>
 </tile>
 <tile id="1669">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_6.png"/>
 </tile>
 <tile id="1670">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - frame_7.png"/>
 </tile>
 <tile id="1671">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1671" duration="100"/>
   <frame tileid="1672" duration="100"/>
   <frame tileid="1673" duration="100"/>
   <frame tileid="1674" duration="100"/>
   <frame tileid="1675" duration="100"/>
   <frame tileid="1676" duration="100"/>
   <frame tileid="1677" duration="100"/>
   <frame tileid="1678" duration="100"/>
  </animation>
 </tile>
 <tile id="1672">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_1.png"/>
 </tile>
 <tile id="1673">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_2.png"/>
 </tile>
 <tile id="1674">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_3.png"/>
 </tile>
 <tile id="1675">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_4.png"/>
 </tile>
 <tile id="1676">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_5.png"/>
 </tile>
 <tile id="1677">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_6.png"/>
 </tile>
 <tile id="1678">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2 - transparency - frame_7.png"/>
 </tile>
 <tile id="1679">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_2.png"/>
 </tile>
 <tile id="1680">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_0.png"/>
  <animation>
   <frame tileid="1680" duration="100"/>
   <frame tileid="1681" duration="100"/>
   <frame tileid="1682" duration="100"/>
   <frame tileid="1683" duration="100"/>
   <frame tileid="1684" duration="100"/>
   <frame tileid="1685" duration="100"/>
   <frame tileid="1686" duration="100"/>
   <frame tileid="1687" duration="100"/>
  </animation>
 </tile>
 <tile id="1681">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_1.png"/>
 </tile>
 <tile id="1682">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_2.png"/>
 </tile>
 <tile id="1683">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_3.png"/>
 </tile>
 <tile id="1684">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_4.png"/>
 </tile>
 <tile id="1685">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_5.png"/>
 </tile>
 <tile id="1686">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_6.png"/>
 </tile>
 <tile id="1687">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - frame_7.png"/>
 </tile>
 <tile id="1688">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1688" duration="100"/>
   <frame tileid="1689" duration="100"/>
   <frame tileid="1690" duration="100"/>
   <frame tileid="1691" duration="100"/>
   <frame tileid="1692" duration="100"/>
   <frame tileid="1693" duration="100"/>
   <frame tileid="1694" duration="100"/>
   <frame tileid="1695" duration="100"/>
  </animation>
 </tile>
 <tile id="1689">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_1.png"/>
 </tile>
 <tile id="1690">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_2.png"/>
 </tile>
 <tile id="1691">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_3.png"/>
 </tile>
 <tile id="1692">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_4.png"/>
 </tile>
 <tile id="1693">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_5.png"/>
 </tile>
 <tile id="1694">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_6.png"/>
 </tile>
 <tile id="1695">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3 - transparency - frame_7.png"/>
 </tile>
 <tile id="1696">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_3.png"/>
 </tile>
 <tile id="1697">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_0.png"/>
  <animation>
   <frame tileid="1697" duration="100"/>
   <frame tileid="1698" duration="100"/>
   <frame tileid="1699" duration="100"/>
   <frame tileid="1700" duration="100"/>
   <frame tileid="1701" duration="100"/>
   <frame tileid="1702" duration="100"/>
   <frame tileid="1703" duration="100"/>
   <frame tileid="1704" duration="100"/>
  </animation>
 </tile>
 <tile id="1698">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_1.png"/>
 </tile>
 <tile id="1699">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_2.png"/>
 </tile>
 <tile id="1700">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_3.png"/>
 </tile>
 <tile id="1701">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_4.png"/>
 </tile>
 <tile id="1702">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_5.png"/>
 </tile>
 <tile id="1703">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_6.png"/>
 </tile>
 <tile id="1704">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - frame_7.png"/>
 </tile>
 <tile id="1705">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1705" duration="100"/>
   <frame tileid="1706" duration="100"/>
   <frame tileid="1707" duration="100"/>
   <frame tileid="1708" duration="100"/>
   <frame tileid="1709" duration="100"/>
   <frame tileid="1710" duration="100"/>
   <frame tileid="1711" duration="100"/>
   <frame tileid="1712" duration="100"/>
  </animation>
 </tile>
 <tile id="1706">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_1.png"/>
 </tile>
 <tile id="1707">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_2.png"/>
 </tile>
 <tile id="1708">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_3.png"/>
 </tile>
 <tile id="1709">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_4.png"/>
 </tile>
 <tile id="1710">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_5.png"/>
 </tile>
 <tile id="1711">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_6.png"/>
 </tile>
 <tile id="1712">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4 - transparency - frame_7.png"/>
 </tile>
 <tile id="1713">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_4.png"/>
 </tile>
 <tile id="1714">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_0.png"/>
  <animation>
   <frame tileid="1714" duration="100"/>
   <frame tileid="1715" duration="100"/>
   <frame tileid="1716" duration="100"/>
   <frame tileid="1717" duration="100"/>
   <frame tileid="1718" duration="100"/>
   <frame tileid="1719" duration="100"/>
   <frame tileid="1720" duration="100"/>
   <frame tileid="1721" duration="100"/>
  </animation>
 </tile>
 <tile id="1715">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_1.png"/>
 </tile>
 <tile id="1716">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_2.png"/>
 </tile>
 <tile id="1717">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_3.png"/>
 </tile>
 <tile id="1718">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_4.png"/>
 </tile>
 <tile id="1719">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_5.png"/>
 </tile>
 <tile id="1720">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_6.png"/>
 </tile>
 <tile id="1721">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - frame_7.png"/>
 </tile>
 <tile id="1722">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1722" duration="100"/>
   <frame tileid="1723" duration="100"/>
   <frame tileid="1724" duration="100"/>
   <frame tileid="1725" duration="100"/>
   <frame tileid="1726" duration="100"/>
   <frame tileid="1727" duration="100"/>
   <frame tileid="1728" duration="100"/>
   <frame tileid="1729" duration="100"/>
  </animation>
 </tile>
 <tile id="1723">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_1.png"/>
 </tile>
 <tile id="1724">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_2.png"/>
 </tile>
 <tile id="1725">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_3.png"/>
 </tile>
 <tile id="1726">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_4.png"/>
 </tile>
 <tile id="1727">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_5.png"/>
 </tile>
 <tile id="1728">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_6.png"/>
 </tile>
 <tile id="1729">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5 - transparency - frame_7.png"/>
 </tile>
 <tile id="1730">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_5.png"/>
 </tile>
 <tile id="1731">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_0.png"/>
  <animation>
   <frame tileid="1731" duration="100"/>
   <frame tileid="1732" duration="100"/>
   <frame tileid="1733" duration="100"/>
   <frame tileid="1734" duration="100"/>
   <frame tileid="1735" duration="100"/>
   <frame tileid="1736" duration="100"/>
   <frame tileid="1737" duration="100"/>
   <frame tileid="1738" duration="100"/>
  </animation>
 </tile>
 <tile id="1732">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_1.png"/>
 </tile>
 <tile id="1733">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_2.png"/>
 </tile>
 <tile id="1734">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_3.png"/>
 </tile>
 <tile id="1735">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_4.png"/>
 </tile>
 <tile id="1736">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_5.png"/>
 </tile>
 <tile id="1737">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_6.png"/>
 </tile>
 <tile id="1738">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - frame_7.png"/>
 </tile>
 <tile id="1739">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1739" duration="100"/>
   <frame tileid="1740" duration="100"/>
   <frame tileid="1741" duration="100"/>
   <frame tileid="1742" duration="100"/>
   <frame tileid="1743" duration="100"/>
   <frame tileid="1744" duration="100"/>
   <frame tileid="1745" duration="100"/>
   <frame tileid="1746" duration="100"/>
  </animation>
 </tile>
 <tile id="1740">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_1.png"/>
 </tile>
 <tile id="1741">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_2.png"/>
 </tile>
 <tile id="1742">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_3.png"/>
 </tile>
 <tile id="1743">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_4.png"/>
 </tile>
 <tile id="1744">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_5.png"/>
 </tile>
 <tile id="1745">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_6.png"/>
 </tile>
 <tile id="1746">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6 - transparency - frame_7.png"/>
 </tile>
 <tile id="1747">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_6.png"/>
 </tile>
 <tile id="1748">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_7.png"/>
 </tile>
 <tile id="1749">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_8.png"/>
 </tile>
 <tile id="1750">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_9.png"/>
 </tile>
 <tile id="1751">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_10.png"/>
 </tile>
 <tile id="1752">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_11.png"/>
 </tile>
 <tile id="1753">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_12.png"/>
 </tile>
 <tile id="1754">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_13.png"/>
 </tile>
 <tile id="1755">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_14.png"/>
 </tile>
 <tile id="1756">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_15.png"/>
 </tile>
 <tile id="1757">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_16.png"/>
 </tile>
 <tile id="1758">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_17.png"/>
 </tile>
 <tile id="1759">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_18.png"/>
 </tile>
 <tile id="1760">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_19.png"/>
 </tile>
 <tile id="1761">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_20.png"/>
 </tile>
 <tile id="1762">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_21.png"/>
 </tile>
 <tile id="1763">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_22.png"/>
 </tile>
 <tile id="1764">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_23.png"/>
 </tile>
 <tile id="1765">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_24.png"/>
 </tile>
 <tile id="1766">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_25.png"/>
 </tile>
 <tile id="1767">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_26.png"/>
 </tile>
 <tile id="1768">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_27.png"/>
 </tile>
 <tile id="1769">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_28.png"/>
 </tile>
 <tile id="1770">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_29.png"/>
 </tile>
 <tile id="1771">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_30.png"/>
 </tile>
 <tile id="1772">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_0.png"/>
  <animation>
   <frame tileid="1772" duration="100"/>
   <frame tileid="1773" duration="100"/>
   <frame tileid="1774" duration="100"/>
   <frame tileid="1775" duration="100"/>
   <frame tileid="1776" duration="100"/>
   <frame tileid="1777" duration="100"/>
   <frame tileid="1778" duration="100"/>
   <frame tileid="1779" duration="100"/>
  </animation>
 </tile>
 <tile id="1773">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_1.png"/>
 </tile>
 <tile id="1774">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_2.png"/>
 </tile>
 <tile id="1775">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_3.png"/>
 </tile>
 <tile id="1776">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_4.png"/>
 </tile>
 <tile id="1777">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_5.png"/>
 </tile>
 <tile id="1778">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_6.png"/>
 </tile>
 <tile id="1779">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - frame_7.png"/>
 </tile>
 <tile id="1780">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_0.png"/>
  <animation>
   <frame tileid="1780" duration="100"/>
   <frame tileid="1781" duration="100"/>
   <frame tileid="1782" duration="100"/>
   <frame tileid="1783" duration="100"/>
   <frame tileid="1784" duration="100"/>
   <frame tileid="1785" duration="100"/>
   <frame tileid="1786" duration="100"/>
   <frame tileid="1787" duration="100"/>
  </animation>
 </tile>
 <tile id="1781">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_1.png"/>
 </tile>
 <tile id="1782">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_2.png"/>
 </tile>
 <tile id="1783">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_3.png"/>
 </tile>
 <tile id="1784">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_4.png"/>
 </tile>
 <tile id="1785">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_5.png"/>
 </tile>
 <tile id="1786">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_6.png"/>
 </tile>
 <tile id="1787">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/bones_31 - transparency - frame_7.png"/>
 </tile>
 <tile id="1788">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_31.png"/>
 </tile>
 <tile id="1789">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/bones_32.png"/>
 </tile>
 <tile id="1790">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_0.png"/>
 </tile>
 <tile id="1791">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_1.png"/>
 </tile>
 <tile id="1792">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_2.png"/>
 </tile>
 <tile id="1793">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_3.png"/>
 </tile>
 <tile id="1794">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_4.png"/>
 </tile>
 <tile id="1795">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_5.png"/>
 </tile>
 <tile id="1796">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_6.png"/>
 </tile>
 <tile id="1797">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_7.png"/>
 </tile>
 <tile id="1798">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_8.png"/>
 </tile>
 <tile id="1799">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_9.png"/>
 </tile>
 <tile id="1800">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_10.png"/>
 </tile>
 <tile id="1801">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_11.png"/>
 </tile>
 <tile id="1802">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_12.png"/>
 </tile>
 <tile id="1803">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_13.png"/>
 </tile>
 <tile id="1804">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_14.png"/>
 </tile>
 <tile id="1805">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/broken sword for the environment_15.png"/>
 </tile>
 <tile id="1806">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_0.png"/>
  <animation>
   <frame tileid="1806" duration="100"/>
   <frame tileid="1807" duration="100"/>
   <frame tileid="1808" duration="100"/>
   <frame tileid="1809" duration="100"/>
   <frame tileid="1810" duration="100"/>
   <frame tileid="1811" duration="100"/>
   <frame tileid="1812" duration="100"/>
   <frame tileid="1813" duration="100"/>
  </animation>
 </tile>
 <tile id="1807">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_1.png"/>
 </tile>
 <tile id="1808">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_2.png"/>
 </tile>
 <tile id="1809">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_3.png"/>
 </tile>
 <tile id="1810">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_4.png"/>
 </tile>
 <tile id="1811">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_5.png"/>
 </tile>
 <tile id="1812">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_6.png"/>
 </tile>
 <tile id="1813">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 1_7.png"/>
 </tile>
 <tile id="1814">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_0.png"/>
  <animation>
   <frame tileid="1814" duration="100"/>
   <frame tileid="1815" duration="100"/>
   <frame tileid="1816" duration="100"/>
   <frame tileid="1817" duration="100"/>
   <frame tileid="1818" duration="100"/>
   <frame tileid="1819" duration="100"/>
   <frame tileid="1820" duration="100"/>
   <frame tileid="1821" duration="100"/>
  </animation>
 </tile>
 <tile id="1815">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_1.png"/>
 </tile>
 <tile id="1816">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_2.png"/>
 </tile>
 <tile id="1817">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_3.png"/>
 </tile>
 <tile id="1818">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_4.png"/>
 </tile>
 <tile id="1819">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_5.png"/>
 </tile>
 <tile id="1820">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_6.png"/>
 </tile>
 <tile id="1821">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 2_7.png"/>
 </tile>
 <tile id="1822">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_0.png"/>
  <animation>
   <frame tileid="1822" duration="100"/>
   <frame tileid="1823" duration="100"/>
   <frame tileid="1824" duration="100"/>
   <frame tileid="1825" duration="100"/>
   <frame tileid="1826" duration="100"/>
   <frame tileid="1827" duration="100"/>
   <frame tileid="1828" duration="100"/>
   <frame tileid="1829" duration="100"/>
  </animation>
 </tile>
 <tile id="1823">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_1.png"/>
 </tile>
 <tile id="1824">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_2.png"/>
 </tile>
 <tile id="1825">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_3.png"/>
 </tile>
 <tile id="1826">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_4.png"/>
 </tile>
 <tile id="1827">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_5.png"/>
 </tile>
 <tile id="1828">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_6.png"/>
 </tile>
 <tile id="1829">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/chest - animation style 3_7.png"/>
 </tile>
 <tile id="1830">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/Improvised bridge_0.png"/>
 </tile>
 <tile id="1831">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/Improvised bridge_1.png"/>
 </tile>
 <tile id="1832">
  <image width="32" height="128" source="../Props/atlas props - individual sprites/Improvised bridge_2.png"/>
 </tile>
 <tile id="1833">
  <image width="32" height="160" source="../Props/atlas props - individual sprites/Improvised bridge_3.png"/>
 </tile>
 <tile id="1834">
  <image width="64" height="160" source="../Props/atlas props - individual sprites/Improvised bridge_4.png"/>
 </tile>
 <tile id="1835">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/Improvised bridge_5.png"/>
 </tile>
 <tile id="1836">
  <image width="64" height="128" source="../Props/atlas props - individual sprites/Improvised bridge_6.png"/>
 </tile>
 <tile id="1837">
  <image width="64" height="160" source="../Props/atlas props - individual sprites/Improvised bridge_7.png"/>
 </tile>
 <tile id="1838">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/Improvised bridge_8.png"/>
 </tile>
 <tile id="1839">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/Improvised bridge_9.png"/>
 </tile>
 <tile id="1840">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/Improvised bridge_10.png"/>
 </tile>
 <tile id="1841">
  <image width="160" height="64" source="../Props/atlas props - individual sprites/Improvised bridge_11.png"/>
 </tile>
 <tile id="1842">
  <image width="160" height="32" source="../Props/atlas props - individual sprites/Improvised bridge_12.png"/>
 </tile>
 <tile id="1843">
  <image width="160" height="32" source="../Props/atlas props - individual sprites/Improvised bridge_13.png"/>
 </tile>
 <tile id="1844">
  <image width="128" height="32" source="../Props/atlas props - individual sprites/Improvised bridge_14.png"/>
 </tile>
 <tile id="1845">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/Improvised bridge_15.png"/>
 </tile>
 <tile id="1846">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/Improvised bridge_16.png"/>
 </tile>
 <tile id="1847">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/Improvised bridge_17.png"/>
 </tile>
 <tile id="1848">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom left.png"/>
 </tile>
 <tile id="1849">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom left2.png"/>
 </tile>
 <tile id="1850">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom left3.png"/>
 </tile>
 <tile id="1851">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom right.png"/>
 </tile>
 <tile id="1852">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom right2.png"/>
 </tile>
 <tile id="1853">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom right3.png"/>
 </tile>
 <tile id="1854">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom top.png"/>
 </tile>
 <tile id="1855">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - bottom top2.png"/>
 </tile>
 <tile id="1856">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - dead end left.png"/>
 </tile>
 <tile id="1857">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - dead end right.png"/>
 </tile>
 <tile id="1858">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left bottom.png"/>
 </tile>
 <tile id="1859">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left right.png"/>
 </tile>
 <tile id="1860">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left right2.png"/>
 </tile>
 <tile id="1861">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left right3.png"/>
 </tile>
 <tile id="1862">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left right4.png"/>
 </tile>
 <tile id="1863">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left top.png"/>
 </tile>
 <tile id="1864">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - left top2.png"/>
 </tile>
 <tile id="1865">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - right bottom.png"/>
 </tile>
 <tile id="1866">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - top bottom.png"/>
 </tile>
 <tile id="1867">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - top left3.png"/>
 </tile>
 <tile id="1868">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - top right.png"/>
 </tile>
 <tile id="1869">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - top right2.png"/>
 </tile>
 <tile id="1870">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/iron bars to be used on the celling - top right3.png"/>
 </tile>
 <tile id="1871">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - book1.png"/>
 </tile>
 <tile id="1872">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - book2.png"/>
 </tile>
 <tile id="1873">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - broken capsule.png"/>
 </tile>
 <tile id="1874">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_0.png"/>
  <animation>
   <frame tileid="1874" duration="100"/>
   <frame tileid="1875" duration="100"/>
   <frame tileid="1876" duration="100"/>
   <frame tileid="1877" duration="100"/>
   <frame tileid="1878" duration="100"/>
   <frame tileid="1879" duration="100"/>
   <frame tileid="1880" duration="100"/>
   <frame tileid="1881" duration="100"/>
  </animation>
 </tile>
 <tile id="1875">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_1.png"/>
 </tile>
 <tile id="1876">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_2.png"/>
 </tile>
 <tile id="1877">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_3.png"/>
 </tile>
 <tile id="1878">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_4.png"/>
 </tile>
 <tile id="1879">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_5.png"/>
 </tile>
 <tile id="1880">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_6.png"/>
 </tile>
 <tile id="1881">
  <image width="32" height="64" source="../Props/atlas props - individual sprites/laboratory - capusle - animated content - frame_7.png"/>
 </tile>
 <tile id="1882">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/laboratory - capusle.png"/>
 </tile>
 <tile id="1883">
  <image width="160" height="128" source="../Props/atlas props - individual sprites/laboratory - caspules and piles.png"/>
 </tile>
 <tile id="1884">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/laboratory - engine.png"/>
 </tile>
 <tile id="1885">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - mug.png"/>
 </tile>
 <tile id="1886">
  <image width="160" height="96" source="../Props/atlas props - individual sprites/laboratory - pipes.png"/>
 </tile>
 <tile id="1887">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions support_0.png"/>
 </tile>
 <tile id="1888">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions support_1.png"/>
 </tile>
 <tile id="1889">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions support_2.png"/>
 </tile>
 <tile id="1890">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_0.png"/>
 </tile>
 <tile id="1891">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_1.png"/>
 </tile>
 <tile id="1892">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_2.png"/>
 </tile>
 <tile id="1893">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_3.png"/>
 </tile>
 <tile id="1894">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_4.png"/>
 </tile>
 <tile id="1895">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_5.png"/>
 </tile>
 <tile id="1896">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_6.png"/>
 </tile>
 <tile id="1897">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_7.png"/>
 </tile>
 <tile id="1898">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_8.png"/>
 </tile>
 <tile id="1899">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_9.png"/>
 </tile>
 <tile id="1900">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_10.png"/>
 </tile>
 <tile id="1901">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_11.png"/>
 </tile>
 <tile id="1902">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_12.png"/>
 </tile>
 <tile id="1903">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_13.png"/>
 </tile>
 <tile id="1904">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_14.png"/>
 </tile>
 <tile id="1905">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/laboratory - potions_15.png"/>
 </tile>
 <tile id="1906">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/laboratory - shelves1.png"/>
 </tile>
 <tile id="1907">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/laboratory - shelves2.png"/>
 </tile>
 <tile id="1908">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/laboratory - small pipes.png"/>
 </tile>
 <tile id="1909">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/laboratory - table.png"/>
 </tile>
 <tile id="1910">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks 18.png"/>
 </tile>
 <tile id="1911">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks 19.png"/>
 </tile>
 <tile id="1912">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_0.png"/>
 </tile>
 <tile id="1913">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_1.png"/>
 </tile>
 <tile id="1914">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_2.png"/>
 </tile>
 <tile id="1915">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_3.png"/>
 </tile>
 <tile id="1916">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_4.png"/>
 </tile>
 <tile id="1917">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_5.png"/>
 </tile>
 <tile id="1918">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_6.png"/>
 </tile>
 <tile id="1919">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_7.png"/>
 </tile>
 <tile id="1920">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_8.png"/>
 </tile>
 <tile id="1921">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_9.png"/>
 </tile>
 <tile id="1922">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_10.png"/>
 </tile>
 <tile id="1923">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_11.png"/>
 </tile>
 <tile id="1924">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_12.png"/>
 </tile>
 <tile id="1925">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_13.png"/>
 </tile>
 <tile id="1926">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/little rocks_14.png"/>
 </tile>
 <tile id="1927">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/little rocks_15.png"/>
 </tile>
 <tile id="1928">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/little rocks_16.png"/>
 </tile>
 <tile id="1929">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/little rocks_17.png"/>
 </tile>
 <tile id="1930">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_0.png"/>
 </tile>
 <tile id="1931">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_1.png"/>
 </tile>
 <tile id="1932">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_2.png"/>
 </tile>
 <tile id="1933">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_3.png"/>
 </tile>
 <tile id="1934">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_4.png"/>
 </tile>
 <tile id="1935">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_5.png"/>
 </tile>
 <tile id="1936">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_6.png"/>
 </tile>
 <tile id="1937">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_7.png"/>
 </tile>
 <tile id="1938">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_8.png"/>
 </tile>
 <tile id="1939">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_9.png"/>
 </tile>
 <tile id="1940">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_10.png"/>
 </tile>
 <tile id="1941">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_11.png"/>
 </tile>
 <tile id="1942">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_12.png"/>
 </tile>
 <tile id="1943">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_13.png"/>
 </tile>
 <tile id="1944">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_14.png"/>
 </tile>
 <tile id="1945">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_15.png"/>
 </tile>
 <tile id="1946">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_16.png"/>
 </tile>
 <tile id="1947">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_17.png"/>
 </tile>
 <tile id="1948">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_18.png"/>
 </tile>
 <tile id="1949">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_19.png"/>
 </tile>
 <tile id="1950">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_20.png"/>
 </tile>
 <tile id="1951">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the celling_21.png"/>
 </tile>
 <tile id="1952">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_0.png"/>
 </tile>
 <tile id="1953">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_1.png"/>
 </tile>
 <tile id="1954">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_2.png"/>
 </tile>
 <tile id="1955">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_3.png"/>
 </tile>
 <tile id="1956">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_4.png"/>
 </tile>
 <tile id="1957">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_5.png"/>
 </tile>
 <tile id="1958">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_6.png"/>
 </tile>
 <tile id="1959">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_7.png"/>
 </tile>
 <tile id="1960">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_8.png"/>
 </tile>
 <tile id="1961">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_9.png"/>
 </tile>
 <tile id="1962">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_10.png"/>
 </tile>
 <tile id="1963">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_11.png"/>
 </tile>
 <tile id="1964">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_12.png"/>
 </tile>
 <tile id="1965">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_13.png"/>
 </tile>
 <tile id="1966">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_14.png"/>
 </tile>
 <tile id="1967">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_15.png"/>
 </tile>
 <tile id="1968">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_16.png"/>
 </tile>
 <tile id="1969">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_17.png"/>
 </tile>
 <tile id="1970">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_18.png"/>
 </tile>
 <tile id="1971">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_19.png"/>
 </tile>
 <tile id="1972">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_20.png"/>
 </tile>
 <tile id="1973">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_21.png"/>
 </tile>
 <tile id="1974">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_22.png"/>
 </tile>
 <tile id="1975">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_23.png"/>
 </tile>
 <tile id="1976">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_24.png"/>
 </tile>
 <tile id="1977">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_25.png"/>
 </tile>
 <tile id="1978">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_26.png"/>
 </tile>
 <tile id="1979">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_27.png"/>
 </tile>
 <tile id="1980">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_28.png"/>
 </tile>
 <tile id="1981">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_29.png"/>
 </tile>
 <tile id="1982">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_30.png"/>
 </tile>
 <tile id="1983">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_31.png"/>
 </tile>
 <tile id="1984">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_32.png"/>
 </tile>
 <tile id="1985">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_33.png"/>
 </tile>
 <tile id="1986">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_34.png"/>
 </tile>
 <tile id="1987">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_35.png"/>
 </tile>
 <tile id="1988">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_36.png"/>
 </tile>
 <tile id="1989">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_37.png"/>
 </tile>
 <tile id="1990">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_38.png"/>
 </tile>
 <tile id="1991">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_39.png"/>
 </tile>
 <tile id="1992">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_40.png"/>
 </tile>
 <tile id="1993">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_41.png"/>
 </tile>
 <tile id="1994">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_42.png"/>
 </tile>
 <tile id="1995">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_47.png"/>
 </tile>
 <tile id="1996">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_48.png"/>
 </tile>
 <tile id="1997">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_466.png"/>
 </tile>
 <tile id="1998">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 1_477.png"/>
 </tile>
 <tile id="1999">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_0.png"/>
 </tile>
 <tile id="2000">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_1.png"/>
 </tile>
 <tile id="2001">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_2.png"/>
 </tile>
 <tile id="2002">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_3.png"/>
 </tile>
 <tile id="2003">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_4.png"/>
 </tile>
 <tile id="2004">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_5.png"/>
 </tile>
 <tile id="2005">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_6.png"/>
 </tile>
 <tile id="2006">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_7.png"/>
 </tile>
 <tile id="2007">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_8.png"/>
 </tile>
 <tile id="2008">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_9.png"/>
 </tile>
 <tile id="2009">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_10.png"/>
 </tile>
 <tile id="2010">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_11.png"/>
 </tile>
 <tile id="2011">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_12.png"/>
 </tile>
 <tile id="2012">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_13.png"/>
 </tile>
 <tile id="2013">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_14.png"/>
 </tile>
 <tile id="2014">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_15.png"/>
 </tile>
 <tile id="2015">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_16.png"/>
 </tile>
 <tile id="2016">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_17.png"/>
 </tile>
 <tile id="2017">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_18.png"/>
 </tile>
 <tile id="2018">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_19.png"/>
 </tile>
 <tile id="2019">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_20.png"/>
 </tile>
 <tile id="2020">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_21.png"/>
 </tile>
 <tile id="2021">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_22.png"/>
 </tile>
 <tile id="2022">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_23.png"/>
 </tile>
 <tile id="2023">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_24.png"/>
 </tile>
 <tile id="2024">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_25.png"/>
 </tile>
 <tile id="2025">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_26.png"/>
 </tile>
 <tile id="2026">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_27.png"/>
 </tile>
 <tile id="2027">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_28.png"/>
 </tile>
 <tile id="2028">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_29.png"/>
 </tile>
 <tile id="2029">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_30.png"/>
 </tile>
 <tile id="2030">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_31.png"/>
 </tile>
 <tile id="2031">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_32.png"/>
 </tile>
 <tile id="2032">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_33.png"/>
 </tile>
 <tile id="2033">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_34.png"/>
 </tile>
 <tile id="2034">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_35.png"/>
 </tile>
 <tile id="2035">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_36.png"/>
 </tile>
 <tile id="2036">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_37.png"/>
 </tile>
 <tile id="2037">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_38.png"/>
 </tile>
 <tile id="2038">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_39.png"/>
 </tile>
 <tile id="2039">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_40.png"/>
 </tile>
 <tile id="2040">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_41.png"/>
 </tile>
 <tile id="2041">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_42.png"/>
 </tile>
 <tile id="2042">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_43.png"/>
 </tile>
 <tile id="2043">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_44.png"/>
 </tile>
 <tile id="2044">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_45.png"/>
 </tile>
 <tile id="2045">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_46.png"/>
 </tile>
 <tile id="2046">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_47.png"/>
 </tile>
 <tile id="2047">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_48.png"/>
 </tile>
 <tile id="2048">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_466.png"/>
 </tile>
 <tile id="2049">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 2_477.png"/>
 </tile>
 <tile id="2050">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_0.png"/>
 </tile>
 <tile id="2051">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_1.png"/>
 </tile>
 <tile id="2052">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_2.png"/>
 </tile>
 <tile id="2053">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_3.png"/>
 </tile>
 <tile id="2054">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_4.png"/>
 </tile>
 <tile id="2055">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_5.png"/>
 </tile>
 <tile id="2056">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_6.png"/>
 </tile>
 <tile id="2057">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_7.png"/>
 </tile>
 <tile id="2058">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_8.png"/>
 </tile>
 <tile id="2059">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_9.png"/>
 </tile>
 <tile id="2060">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_10.png"/>
 </tile>
 <tile id="2061">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_11.png"/>
 </tile>
 <tile id="2062">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_12.png"/>
 </tile>
 <tile id="2063">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_13.png"/>
 </tile>
 <tile id="2064">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_14.png"/>
 </tile>
 <tile id="2065">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_15.png"/>
 </tile>
 <tile id="2066">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_16.png"/>
 </tile>
 <tile id="2067">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_17.png"/>
 </tile>
 <tile id="2068">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_18.png"/>
 </tile>
 <tile id="2069">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_19.png"/>
 </tile>
 <tile id="2070">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_20.png"/>
 </tile>
 <tile id="2071">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_21.png"/>
 </tile>
 <tile id="2072">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_22.png"/>
 </tile>
 <tile id="2073">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_23.png"/>
 </tile>
 <tile id="2074">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_24.png"/>
 </tile>
 <tile id="2075">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_25.png"/>
 </tile>
 <tile id="2076">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_26.png"/>
 </tile>
 <tile id="2077">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_27.png"/>
 </tile>
 <tile id="2078">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_28.png"/>
 </tile>
 <tile id="2079">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_29.png"/>
 </tile>
 <tile id="2080">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_30.png"/>
 </tile>
 <tile id="2081">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_31.png"/>
 </tile>
 <tile id="2082">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_32.png"/>
 </tile>
 <tile id="2083">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_33.png"/>
 </tile>
 <tile id="2084">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_34.png"/>
 </tile>
 <tile id="2085">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_35.png"/>
 </tile>
 <tile id="2086">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_36.png"/>
 </tile>
 <tile id="2087">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_37.png"/>
 </tile>
 <tile id="2088">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_38.png"/>
 </tile>
 <tile id="2089">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_39.png"/>
 </tile>
 <tile id="2090">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_40.png"/>
 </tile>
 <tile id="2091">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_41.png"/>
 </tile>
 <tile id="2092">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_42.png"/>
 </tile>
 <tile id="2093">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_43.png"/>
 </tile>
 <tile id="2094">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_44.png"/>
 </tile>
 <tile id="2095">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_45.png"/>
 </tile>
 <tile id="2096">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_47.png"/>
 </tile>
 <tile id="2097">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_48.png"/>
 </tile>
 <tile id="2098">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_49.png"/>
 </tile>
 <tile id="2099">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/metal pipes on the wall - color scheme 3_50.png"/>
 </tile>
 <tile id="2100">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/Slice 4.png"/>
 </tile>
 <tile id="2101">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/Slice_10.png"/>
 </tile>
 <tile id="2102">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - 4 directions.png"/>
 </tile>
 <tile id="2103">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - dead end - left.png"/>
 </tile>
 <tile id="2104">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - dead end bottom.png"/>
 </tile>
 <tile id="2105">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - dead end right.png"/>
 </tile>
 <tile id="2106">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - dead end top.png"/>
 </tile>
 <tile id="2107">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left bottom.png"/>
 </tile>
 <tile id="2108">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left right bottom.png"/>
 </tile>
 <tile id="2109">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left right top.png"/>
 </tile>
 <tile id="2110">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left right.png"/>
 </tile>
 <tile id="2111">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left right2.png"/>
 </tile>
 <tile id="2112">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left top bottom.png"/>
 </tile>
 <tile id="2113">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - left top.png"/>
 </tile>
 <tile id="2114">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - right bottom.png"/>
 </tile>
 <tile id="2115">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - top bottom right.png"/>
 </tile>
 <tile id="2116">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - top bottom.png"/>
 </tile>
 <tile id="2117">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/submerged pipes - top right.png"/>
 </tile>
 <tile id="2118">
  <image width="128" height="65" source="../Props/atlas props - individual sprites/web - color scheme 1_0.png"/>
 </tile>
 <tile id="2119">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_1.png"/>
 </tile>
 <tile id="2120">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_2.png"/>
 </tile>
 <tile id="2121">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 1_3.png"/>
 </tile>
 <tile id="2122">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_4.png"/>
 </tile>
 <tile id="2123">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_5.png"/>
 </tile>
 <tile id="2124">
  <image width="96" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_6.png"/>
 </tile>
 <tile id="2125">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/web - color scheme 1_7.png"/>
 </tile>
 <tile id="2126">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/web - color scheme 1_8.png"/>
 </tile>
 <tile id="2127">
  <image width="128" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_9.png"/>
 </tile>
 <tile id="2128">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 1_10.png"/>
 </tile>
 <tile id="2129">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 1_11.png"/>
 </tile>
 <tile id="2130">
  <image width="128" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_12.png"/>
 </tile>
 <tile id="2131">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_13.png"/>
 </tile>
 <tile id="2132">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/web - color scheme 1_14.png"/>
 </tile>
 <tile id="2133">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_15.png"/>
 </tile>
 <tile id="2134">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_16.png"/>
 </tile>
 <tile id="2135">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_17.png"/>
 </tile>
 <tile id="2136">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_18.png"/>
 </tile>
 <tile id="2137">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_19.png"/>
 </tile>
 <tile id="2138">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_20.png"/>
 </tile>
 <tile id="2139">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_21.png"/>
 </tile>
 <tile id="2140">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_22.png"/>
 </tile>
 <tile id="2141">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_23.png"/>
 </tile>
 <tile id="2142">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_24.png"/>
 </tile>
 <tile id="2143">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_25.png"/>
 </tile>
 <tile id="2144">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_26.png"/>
 </tile>
 <tile id="2145">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_27.png"/>
 </tile>
 <tile id="2146">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_28.png"/>
 </tile>
 <tile id="2147">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_29.png"/>
 </tile>
 <tile id="2148">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_30.png"/>
 </tile>
 <tile id="2149">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_31.png"/>
 </tile>
 <tile id="2150">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_32.png"/>
 </tile>
 <tile id="2151">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_33.png"/>
 </tile>
 <tile id="2152">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_34.png"/>
 </tile>
 <tile id="2153">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_35.png"/>
 </tile>
 <tile id="2154">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_36.png"/>
 </tile>
 <tile id="2155">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_37.png"/>
 </tile>
 <tile id="2156">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_38.png"/>
 </tile>
 <tile id="2157">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_39.png"/>
 </tile>
 <tile id="2158">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_40.png"/>
 </tile>
 <tile id="2159">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_41.png"/>
 </tile>
 <tile id="2160">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_42.png"/>
 </tile>
 <tile id="2161">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_43.png"/>
 </tile>
 <tile id="2162">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_44.png"/>
 </tile>
 <tile id="2163">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_45.png"/>
 </tile>
 <tile id="2164">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_46.png"/>
 </tile>
 <tile id="2165">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 1_47.png"/>
 </tile>
 <tile id="2166">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_48.png"/>
 </tile>
 <tile id="2167">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_49.png"/>
 </tile>
 <tile id="2168">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_50.png"/>
 </tile>
 <tile id="2169">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_51.png"/>
 </tile>
 <tile id="2170">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_52.png"/>
 </tile>
 <tile id="2171">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/web - color scheme 1_53.png"/>
 </tile>
 <tile id="2172">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_0.png"/>
 </tile>
 <tile id="2173">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_1.png"/>
 </tile>
 <tile id="2174">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_2.png"/>
 </tile>
 <tile id="2175">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_3.png"/>
 </tile>
 <tile id="2176">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_4.png"/>
 </tile>
 <tile id="2177">
  <image width="32" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_5.png"/>
 </tile>
 <tile id="2178">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_6.png"/>
 </tile>
 <tile id="2179">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_7.png"/>
 </tile>
 <tile id="2180">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_8.png"/>
 </tile>
 <tile id="2181">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_9.png"/>
 </tile>
 <tile id="2182">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_10.png"/>
 </tile>
 <tile id="2183">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_11.png"/>
 </tile>
 <tile id="2184">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_12.png"/>
 </tile>
 <tile id="2185">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_13.png"/>
 </tile>
 <tile id="2186">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_14.png"/>
 </tile>
 <tile id="2187">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_15.png"/>
 </tile>
 <tile id="2188">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_16.png"/>
 </tile>
 <tile id="2189">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_17.png"/>
 </tile>
 <tile id="2190">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_18.png"/>
 </tile>
 <tile id="2191">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_19.png"/>
 </tile>
 <tile id="2192">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_20.png"/>
 </tile>
 <tile id="2193">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_21.png"/>
 </tile>
 <tile id="2194">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_22.png"/>
 </tile>
 <tile id="2195">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_23.png"/>
 </tile>
 <tile id="2196">
  <image width="96" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_24.png"/>
 </tile>
 <tile id="2197">
  <image width="128" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_25.png"/>
 </tile>
 <tile id="2198">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_26.png"/>
 </tile>
 <tile id="2199">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_27.png"/>
 </tile>
 <tile id="2200">
  <image width="128" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_28.png"/>
 </tile>
 <tile id="2201">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_29.png"/>
 </tile>
 <tile id="2202">
  <image width="96" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_30.png"/>
 </tile>
 <tile id="2203">
  <image width="96" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_31.png"/>
 </tile>
 <tile id="2204">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_32.png"/>
 </tile>
 <tile id="2205">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_33.png"/>
 </tile>
 <tile id="2206">
  <image width="128" height="64" source="../Props/atlas props - individual sprites/web - color scheme 2_34.png"/>
 </tile>
 <tile id="2207">
  <image width="128" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_35.png"/>
 </tile>
 <tile id="2208">
  <image width="128" height="128" source="../Props/atlas props - individual sprites/web - color scheme 2_36.png"/>
 </tile>
 <tile id="2209">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_37.png"/>
 </tile>
 <tile id="2210">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_38.png"/>
 </tile>
 <tile id="2211">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_39.png"/>
 </tile>
 <tile id="2212">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_40.png"/>
 </tile>
 <tile id="2213">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_41.png"/>
 </tile>
 <tile id="2214">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_42.png"/>
 </tile>
 <tile id="2215">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_43.png"/>
 </tile>
 <tile id="2216">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/web - color scheme 2_44.png"/>
 </tile>
 <tile id="2217">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_45.png"/>
 </tile>
 <tile id="2218">
  <image width="64" height="96" source="../Props/atlas props - individual sprites/web - color scheme 2_46.png"/>
 </tile>
 <tile id="2219">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_0.png"/>
 </tile>
 <tile id="2220">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_1.png"/>
 </tile>
 <tile id="2221">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_2.png"/>
 </tile>
 <tile id="2222">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_3.png"/>
 </tile>
 <tile id="2223">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_4.png"/>
 </tile>
 <tile id="2224">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_5.png"/>
 </tile>
 <tile id="2225">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_6.png"/>
 </tile>
 <tile id="2226">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_7.png"/>
 </tile>
 <tile id="2227">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_8.png"/>
 </tile>
 <tile id="2228">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_0.png"/>
  <animation>
   <frame tileid="2228" duration="100"/>
   <frame tileid="2229" duration="100"/>
   <frame tileid="2230" duration="100"/>
   <frame tileid="2231" duration="100"/>
   <frame tileid="2232" duration="100"/>
   <frame tileid="2233" duration="100"/>
   <frame tileid="2234" duration="100"/>
   <frame tileid="2235" duration="100"/>
  </animation>
 </tile>
 <tile id="2229">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_1.png"/>
 </tile>
 <tile id="2230">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_2.png"/>
 </tile>
 <tile id="2231">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_3.png"/>
 </tile>
 <tile id="2232">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_4.png"/>
 </tile>
 <tile id="2233">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_5.png"/>
 </tile>
 <tile id="2234">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_6.png"/>
 </tile>
 <tile id="2235">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9 frame_7.png"/>
 </tile>
 <tile id="2236">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_9.png"/>
 </tile>
 <tile id="2237">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_0.png"/>
  <animation>
   <frame tileid="2237" duration="100"/>
   <frame tileid="2238" duration="100"/>
   <frame tileid="2239" duration="100"/>
   <frame tileid="2240" duration="100"/>
   <frame tileid="2241" duration="100"/>
   <frame tileid="2242" duration="100"/>
   <frame tileid="2243" duration="100"/>
   <frame tileid="2244" duration="100"/>
  </animation>
 </tile>
 <tile id="2238">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_1.png"/>
 </tile>
 <tile id="2239">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_2.png"/>
 </tile>
 <tile id="2240">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_3.png"/>
 </tile>
 <tile id="2241">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_4.png"/>
 </tile>
 <tile id="2242">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_5.png"/>
 </tile>
 <tile id="2243">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_6.png"/>
 </tile>
 <tile id="2244">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10 frame_7.png"/>
 </tile>
 <tile id="2245">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_10.png"/>
 </tile>
 <tile id="2246">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_0.png"/>
  <animation>
   <frame tileid="2246" duration="100"/>
   <frame tileid="2247" duration="100"/>
   <frame tileid="2248" duration="100"/>
   <frame tileid="2249" duration="100"/>
   <frame tileid="2250" duration="100"/>
   <frame tileid="2251" duration="100"/>
   <frame tileid="2252" duration="100"/>
   <frame tileid="2253" duration="100"/>
  </animation>
 </tile>
 <tile id="2247">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_1.png"/>
 </tile>
 <tile id="2248">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_2.png"/>
 </tile>
 <tile id="2249">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_3.png"/>
 </tile>
 <tile id="2250">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_4.png"/>
 </tile>
 <tile id="2251">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_5.png"/>
 </tile>
 <tile id="2252">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_6.png"/>
 </tile>
 <tile id="2253">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11 frame_7.png"/>
 </tile>
 <tile id="2254">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_11.png"/>
 </tile>
 <tile id="2255">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_12.png"/>
 </tile>
 <tile id="2256">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_13.png"/>
 </tile>
 <tile id="2257">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_14.png"/>
 </tile>
 <tile id="2258">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_15.png"/>
 </tile>
 <tile id="2259">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_16.png"/>
 </tile>
 <tile id="2260">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_17.png"/>
 </tile>
 <tile id="2261">
  <image width="64" height="32" source="../Props/atlas props - individual sprites/wooden chests - isometric_18.png"/>
 </tile>
 <tile id="2262">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_19.png"/>
 </tile>
 <tile id="2263">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_20.png"/>
 </tile>
 <tile id="2264">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_21.png"/>
 </tile>
 <tile id="2265">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_0.png"/>
  <animation>
   <frame tileid="2265" duration="100"/>
   <frame tileid="2266" duration="100"/>
   <frame tileid="2267" duration="100"/>
   <frame tileid="2268" duration="100"/>
   <frame tileid="2269" duration="100"/>
   <frame tileid="2270" duration="100"/>
   <frame tileid="2271" duration="100"/>
   <frame tileid="2272" duration="100"/>
  </animation>
 </tile>
 <tile id="2266">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_1.png"/>
 </tile>
 <tile id="2267">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_2.png"/>
 </tile>
 <tile id="2268">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_3.png"/>
 </tile>
 <tile id="2269">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_4.png"/>
 </tile>
 <tile id="2270">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_5.png"/>
 </tile>
 <tile id="2271">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_6.png"/>
 </tile>
 <tile id="2272">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22 frame_7.png"/>
 </tile>
 <tile id="2273">
  <image width="64" height="64" source="../Props/atlas props - individual sprites/wooden chests - isometric_22.png"/>
 </tile>
 <tile id="2274">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_0.png"/>
 </tile>
 <tile id="2275">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_1.png"/>
 </tile>
 <tile id="2276">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_2.png"/>
 </tile>
 <tile id="2277">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_0.png"/>
  <animation>
   <frame tileid="2277" duration="100"/>
   <frame tileid="2278" duration="100"/>
   <frame tileid="2279" duration="100"/>
   <frame tileid="2280" duration="100"/>
   <frame tileid="2281" duration="100"/>
   <frame tileid="2282" duration="100"/>
   <frame tileid="2283" duration="100"/>
   <frame tileid="2284" duration="100"/>
  </animation>
 </tile>
 <tile id="2278">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_1.png"/>
 </tile>
 <tile id="2279">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_2.png"/>
 </tile>
 <tile id="2280">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_3.png"/>
 </tile>
 <tile id="2281">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_4.png"/>
 </tile>
 <tile id="2282">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_5.png"/>
 </tile>
 <tile id="2283">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_6.png"/>
 </tile>
 <tile id="2284">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3 frame_7.png"/>
 </tile>
 <tile id="2285">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_3.png"/>
 </tile>
 <tile id="2286">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_4.png"/>
 </tile>
 <tile id="2287">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_5.png"/>
 </tile>
 <tile id="2288">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_6.png"/>
 </tile>
 <tile id="2289">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_0.png"/>
  <animation>
   <frame tileid="2289" duration="100"/>
   <frame tileid="2290" duration="100"/>
   <frame tileid="2291" duration="100"/>
   <frame tileid="2292" duration="100"/>
   <frame tileid="2293" duration="100"/>
   <frame tileid="2294" duration="100"/>
   <frame tileid="2295" duration="100"/>
   <frame tileid="2296" duration="100"/>
  </animation>
 </tile>
 <tile id="2290">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_1.png"/>
 </tile>
 <tile id="2291">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_2.png"/>
 </tile>
 <tile id="2292">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_3.png"/>
 </tile>
 <tile id="2293">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_4.png"/>
 </tile>
 <tile id="2294">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_5.png"/>
 </tile>
 <tile id="2295">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_6.png"/>
 </tile>
 <tile id="2296">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7 frame_7.png"/>
 </tile>
 <tile id="2297">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_7.png"/>
 </tile>
 <tile id="2298">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_8.png"/>
 </tile>
 <tile id="2299">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_9.png"/>
 </tile>
 <tile id="2300">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_10.png"/>
 </tile>
 <tile id="2301">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_11.png"/>
 </tile>
 <tile id="2302">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_0.png"/>
  <animation>
   <frame tileid="2302" duration="100"/>
   <frame tileid="2303" duration="100"/>
   <frame tileid="2304" duration="100"/>
   <frame tileid="2305" duration="100"/>
   <frame tileid="2306" duration="100"/>
   <frame tileid="2307" duration="100"/>
   <frame tileid="2308" duration="100"/>
   <frame tileid="2309" duration="100"/>
  </animation>
 </tile>
 <tile id="2303">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_1.png"/>
 </tile>
 <tile id="2304">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_2.png"/>
 </tile>
 <tile id="2305">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_3.png"/>
 </tile>
 <tile id="2306">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_4.png"/>
 </tile>
 <tile id="2307">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_5.png"/>
 </tile>
 <tile id="2308">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_6.png"/>
 </tile>
 <tile id="2309">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12 frame_7.png"/>
 </tile>
 <tile id="2310">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_12.png"/>
 </tile>
 <tile id="2311">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_13.png"/>
 </tile>
 <tile id="2312">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_14.png"/>
 </tile>
 <tile id="2313">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_15.png"/>
 </tile>
 <tile id="2314">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_16.png"/>
 </tile>
 <tile id="2315">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_0.png"/>
  <animation>
   <frame tileid="2315" duration="100"/>
   <frame tileid="2316" duration="100"/>
   <frame tileid="2317" duration="100"/>
   <frame tileid="2318" duration="100"/>
   <frame tileid="2319" duration="100"/>
   <frame tileid="2320" duration="100"/>
   <frame tileid="2321" duration="100"/>
   <frame tileid="2322" duration="100"/>
  </animation>
 </tile>
 <tile id="2316">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_1.png"/>
 </tile>
 <tile id="2317">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_2.png"/>
 </tile>
 <tile id="2318">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_3.png"/>
 </tile>
 <tile id="2319">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_4.png"/>
 </tile>
 <tile id="2320">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_5.png"/>
 </tile>
 <tile id="2321">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_6.png"/>
 </tile>
 <tile id="2322">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17 frame_7.png"/>
 </tile>
 <tile id="2323">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - topdown_17.png"/>
 </tile>
 <tile id="2324">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_0.png"/>
  <animation>
   <frame tileid="2324" duration="100"/>
   <frame tileid="2325" duration="100"/>
   <frame tileid="2326" duration="100"/>
   <frame tileid="2327" duration="100"/>
   <frame tileid="2328" duration="100"/>
   <frame tileid="2329" duration="100"/>
   <frame tileid="2330" duration="100"/>
   <frame tileid="2331" duration="100"/>
  </animation>
 </tile>
 <tile id="2325">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_1.png"/>
 </tile>
 <tile id="2326">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_2.png"/>
 </tile>
 <tile id="2327">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_3.png"/>
 </tile>
 <tile id="2328">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_4.png"/>
 </tile>
 <tile id="2329">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_5.png"/>
 </tile>
 <tile id="2330">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_6.png"/>
 </tile>
 <tile id="2331">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_3 frame_7.png"/>
 </tile>
 <tile id="2332">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_0.png"/>
  <animation>
   <frame tileid="2332" duration="100"/>
   <frame tileid="2333" duration="100"/>
   <frame tileid="2334" duration="100"/>
   <frame tileid="2335" duration="100"/>
   <frame tileid="2336" duration="100"/>
   <frame tileid="2337" duration="100"/>
   <frame tileid="2338" duration="100"/>
   <frame tileid="2339" duration="100"/>
  </animation>
 </tile>
 <tile id="2333">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_1.png"/>
 </tile>
 <tile id="2334">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_2.png"/>
 </tile>
 <tile id="2335">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_3.png"/>
 </tile>
 <tile id="2336">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_4.png"/>
 </tile>
 <tile id="2337">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_5.png"/>
 </tile>
 <tile id="2338">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_6.png"/>
 </tile>
 <tile id="2339">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_7 frame_7.png"/>
 </tile>
 <tile id="2340">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_0.png"/>
  <animation>
   <frame tileid="2340" duration="100"/>
   <frame tileid="2341" duration="100"/>
   <frame tileid="2342" duration="100"/>
   <frame tileid="2343" duration="100"/>
   <frame tileid="2344" duration="100"/>
   <frame tileid="2345" duration="100"/>
   <frame tileid="2346" duration="100"/>
   <frame tileid="2347" duration="100"/>
  </animation>
 </tile>
 <tile id="2341">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_1.png"/>
 </tile>
 <tile id="2342">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_2.png"/>
 </tile>
 <tile id="2343">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_3.png"/>
 </tile>
 <tile id="2344">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_4.png"/>
 </tile>
 <tile id="2345">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_5.png"/>
 </tile>
 <tile id="2346">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_6.png"/>
 </tile>
 <tile id="2347">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_12 frame_7.png"/>
 </tile>
 <tile id="2348">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_0.png"/>
  <animation>
   <frame tileid="2348" duration="100"/>
   <frame tileid="2349" duration="100"/>
   <frame tileid="2350" duration="100"/>
   <frame tileid="2351" duration="100"/>
   <frame tileid="2352" duration="100"/>
   <frame tileid="2353" duration="100"/>
   <frame tileid="2354" duration="100"/>
   <frame tileid="2355" duration="100"/>
  </animation>
 </tile>
 <tile id="2349">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_1.png"/>
 </tile>
 <tile id="2350">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_2.png"/>
 </tile>
 <tile id="2351">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_3.png"/>
 </tile>
 <tile id="2352">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_4.png"/>
 </tile>
 <tile id="2353">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_5.png"/>
 </tile>
 <tile id="2354">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_6.png"/>
 </tile>
 <tile id="2355">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden chests - transparency - topdown_17 frame_7.png"/>
 </tile>
 <tile id="2356">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_0.png"/>
 </tile>
 <tile id="2357">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_1.png"/>
 </tile>
 <tile id="2358">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_2.png"/>
 </tile>
 <tile id="2359">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_3.png"/>
 </tile>
 <tile id="2360">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_4.png"/>
 </tile>
 <tile id="2361">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_5.png"/>
 </tile>
 <tile id="2362">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_6.png"/>
 </tile>
 <tile id="2363">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_7.png"/>
 </tile>
 <tile id="2364">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_8.png"/>
 </tile>
 <tile id="2365">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_9.png"/>
 </tile>
 <tile id="2366">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_10.png"/>
 </tile>
 <tile id="2367">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_11.png"/>
 </tile>
 <tile id="2368">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_12.png"/>
 </tile>
 <tile id="2369">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_13.png"/>
 </tile>
 <tile id="2370">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_14.png"/>
 </tile>
 <tile id="2371">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_15.png"/>
 </tile>
 <tile id="2372">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_16.png"/>
 </tile>
 <tile id="2373">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_17.png"/>
 </tile>
 <tile id="2374">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_18.png"/>
 </tile>
 <tile id="2375">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_19.png"/>
 </tile>
 <tile id="2376">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_20.png"/>
 </tile>
 <tile id="2377">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_21.png"/>
 </tile>
 <tile id="2378">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_22.png"/>
 </tile>
 <tile id="2379">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_23.png"/>
 </tile>
 <tile id="2380">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_24.png"/>
 </tile>
 <tile id="2381">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_25.png"/>
 </tile>
 <tile id="2382">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_26.png"/>
 </tile>
 <tile id="2383">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_27.png"/>
 </tile>
 <tile id="2384">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_28.png"/>
 </tile>
 <tile id="2385">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_29.png"/>
 </tile>
 <tile id="2386">
  <image width="32" height="32" source="../Props/atlas props - individual sprites/wooden planks_30.png"/>
 </tile>
</tileset>
