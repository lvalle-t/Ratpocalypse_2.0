<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="wall-3-water" tilewidth="32" tileheight="32" tilecount="119" columns="17">
 <image source="../Tilesets/wall-3-1- inner orientation-water.png" width="544" height="224"/>
 <wangsets>
  <wangset name="wall-3-water" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="3" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="17" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="18" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="20" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="21" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="51" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="53" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="55" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="68" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="69" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="71" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="72" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="86" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="87" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="88" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
